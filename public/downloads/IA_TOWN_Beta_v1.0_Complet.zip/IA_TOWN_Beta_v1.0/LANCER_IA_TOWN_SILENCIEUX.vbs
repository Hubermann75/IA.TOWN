Dim WshShell, fso, appDir, exePath, edgePath, chromePath, appUrl
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

appDir = fso.GetParentFolderName(WScript.ScriptFullName)
exePath = appDir & "\IA_TOWN_Beta_v1.0.exe"

If fso.FileExists(exePath) Then
    WshShell.Run """" & exePath & """", 0, False
    WScript.Quit 0
End If

appUrl = "file:///" & Replace(appDir & "\app\index.html", "\", "/")
edgePath = WshShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe")
If Not fso.FileExists(edgePath) Then
    edgePath = WshShell.ExpandEnvironmentStrings("%ProgramFiles%\Microsoft\Edge\Application\msedge.exe")
End If

If fso.FileExists(edgePath) Then
    WshShell.Run """" & edgePath & """ --app=""" & appUrl & """ --allow-file-access-from-files --window-size=1600,920", 1, False
    WScript.Quit 0
End If

chromePath = WshShell.ExpandEnvironmentStrings("%ProgramFiles%\Google\Chrome\Application\chrome.exe")
If Not fso.FileExists(chromePath) Then
    chromePath = WshShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe")
End If
If Not fso.FileExists(chromePath) Then
    chromePath = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
End If

If fso.FileExists(chromePath) Then
    WshShell.Run """" & chromePath & """ --app=""" & appUrl & """ --allow-file-access-from-files --window-size=1600,920", 1, False
    WScript.Quit 0
End If

WshShell.Run """" & appDir & "\app\index.html""", 1, False
