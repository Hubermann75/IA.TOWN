@echo off
chcp 65001 >nul
title IA TOWN — REVENUE ENGINE V3.0 (BETA V1.0)
color 0B
echo =====================================================================
echo    IA TOWN - REVENUE ENGINE V3.0 & CCC.CONNECT HUB
echo    Lancement de l'application autonome Windows (Beta v1.0)
echo =====================================================================
echo.
echo Initialisation du moteur autonome en cours...

set "APP_DIR=%~dp0"
set "APP_INDEX=%APP_DIR%app\index.html"
set "APP_URL=file:///%APP_INDEX:\=/%"
set "CLOUD_URL=https://ais-dev-ksdeoxi4xdoqllzss2tskc-47512140463.europe-west2.run.app"

rem Verification presence binaire .exe natif
if exist "%APP_DIR%IA_TOWN_Beta_v1.0.exe" (
    echo [DEMARRAGE] Lancement via IA_TOWN_Beta_v1.0.exe...
    start "" "%APP_DIR%IA_TOWN_Beta_v1.0.exe"
    exit /b 0
)

rem Detection Edge
set "EDGE_EXE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

rem Detection Chrome
set "CHROME_EXE="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "CHROME_EXE=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"

if defined EDGE_EXE (
    echo [DEMARRAGE] Lancement en mode application autonome (Edge Engine)...
    start "" "%EDGE_EXE%" --app="%APP_URL%" --allow-file-access-from-files --window-size=1600,920
    exit /b 0
)

if defined CHROME_EXE (
    echo [DEMARRAGE] Lancement en mode application autonome (Chrome Engine)...
    start "" "%CHROME_EXE%" --app="%APP_URL%" --allow-file-access-from-files --window-size=1600,920
    exit /b 0
)

echo [DEMARRAGE] Lancement dans votre navigateur par defaut...
start "" "%APP_INDEX%"
exit /b 0
